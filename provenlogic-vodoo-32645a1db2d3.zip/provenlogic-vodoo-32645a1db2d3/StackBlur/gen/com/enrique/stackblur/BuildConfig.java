/** Automatically generated file. DO NOT MODIFY */
package com.enrique.stackblur;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}