package com.provenlogic.mingle.Models;

/**
 * Created by amal on 07/03/17.
 */
public class NotifyProfileRecieved {
}
