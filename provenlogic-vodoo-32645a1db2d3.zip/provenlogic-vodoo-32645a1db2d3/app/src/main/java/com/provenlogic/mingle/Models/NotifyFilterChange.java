package com.provenlogic.mingle.Models;

/**
 * Created by amal on 01/03/17.
 */
public class NotifyFilterChange {
}
