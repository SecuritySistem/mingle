package com.provenlogic.mingle.Activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.provenlogic.mingle.R;

public class PeopleNearbyActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_people_nearby);
    }
}
