package com.provenlogic.mingle.Receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Created by Anurag on 15/4/17.
 */

public class PushNotificationReceiver extends BroadcastReceiver{

    public PushNotificationReceiver() {
        super();
    }

    @Override
    public void onReceive(Context context, Intent intent) {

    }
}
